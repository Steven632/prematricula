/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 10.4.27-MariaDB : Database - esthonordb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(12) NOT NULL,
  `apellidoP` varchar(15) NOT NULL,
  `apellidoM` varchar(15) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` char(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `admin` */

insert  into `admin`(`id`,`nombre`,`apellidoP`,`apellidoM`,`email`,`password`) values 
(1,'Javier','Quiñones','Galán','javier.quinones3@upr.edu','$2y$10$zUeVnlSMx6Jig8MuA5WIKuWBcJv.oTjHypPw6opWLi.oPZIU0CGT.'),
(2,'Aixa','Ramirez','Toledo','aixa.ramirez@upr.edu','$2y$10$jI9.Wq0WQ2lTVqggY4FEG.uhI97c5OXBOx5w13xjPA8S5OMwgwN1a');

/*Table structure for table `checker` */

DROP TABLE IF EXISTS `checker`;

CREATE TABLE `checker` (
  `bool` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `checker` */

insert  into `checker`(`bool`) values 
(0);

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `course_id` varchar(8) NOT NULL,
  `title` varchar(100) NOT NULL,
  `credits` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `course` */

insert  into `course`(`course_id`,`title`,`credits`) values 
('CCOM3042','Arquitectura de Computadoras',3),
('CCOM4019','Programación en PHP',3),
('CCOM4305','Desarrollo de Páginas para la Internet',4),
('CCOM4306','Desarrollo de Imágenes para la Internet',3),
('EDFI3645','Primeros Auxilios',2),
('FISI3009','Electrónica',3);

/*Table structure for table `enrollment` */

DROP TABLE IF EXISTS `enrollment`;

CREATE TABLE `enrollment` (
  `student_id` varchar(9) NOT NULL,
  `course_id` varchar(8) NOT NULL,
  `section_id` varchar(3) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_id`,`course_id`),
  KEY `course_id` (`course_id`,`section_id`),
  CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `enrollment_ibfk_2` FOREIGN KEY (`course_id`, `section_id`) REFERENCES `section` (`course_id`, `section_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `enrollment` */

insert  into `enrollment`(`student_id`,`course_id`,`section_id`,`status`,`timestamp`) values 
('840211111','CCOM3042','HL1',0,'2022-12-07 01:46:08'),
('840211111','CCOM4019','L10',0,'2022-12-07 01:51:33'),
('840211234','CCOM3042','HL1',0,'2022-12-07 01:51:44'),
('840211234','CCOM4305','V10',0,'2022-12-07 01:51:46'),
('840211234','EDFI3645','LB5',0,'2022-12-07 01:51:48'),
('840211234','FISI3009','M40',0,'2022-12-07 01:51:50'),
('840220000','CCOM3042','HL1',0,'2022-12-07 01:51:18'),
('840220000','CCOM4305','V10',0,'2022-12-07 01:51:21'),
('840220000','EDFI3645','LB5',0,'2022-12-07 01:51:19');

/*Table structure for table `section` */

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `course_id` varchar(8) NOT NULL,
  `section_id` varchar(3) NOT NULL,
  `capacity` tinyint(1) unsigned NOT NULL,
  `available` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`course_id`,`section_id`),
  CONSTRAINT `section_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `section` */

insert  into `section`(`course_id`,`section_id`,`capacity`,`available`) values 
('CCOM3042','HL1',13,13),
('CCOM4019','L10',4,4),
('CCOM4305','V10',11,11),
('CCOM4306','M25',16,16),
('EDFI3645','LB5',13,13),
('FISI3009','M40',15,15);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `student_id` varchar(9) NOT NULL,
  `password` char(60) NOT NULL,
  `name` varchar(50) NOT NULL,
  `year_of_study` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `student` */

insert  into `student`(`student_id`,`password`,`name`,`year_of_study`) values 
('840181542','$2y$10$6upUPeJktKLdIWHLSWhBVexmRhfmhdY538wfJ25e9HoLy2/Yotymu','Yadiel Cruzado Rodriguez',0),
('840211111','$2y$10$byRvWZn9dUDpQMH9xnA71uLgHaiWRzDNKUesoKK08zkxaYel7W5LS','José Puig Hernández',5),
('840211234','$2y$10$yBTmWGbrpmF/qzzqVe1uX.jYo0lqPP24tXbJPk8C0lPgJatkH4uFe','Juan Pérez Pérez',4),
('840220000','$2y$10$GoD0DMGZRVT4.xHNfolnvuD2m0S8lS2KVwp5JYLs8pOqf4E5Llyh2','Norma Torres Herrero',5),
('axramirez','$2y$10$LM5.GF/n4Pa8QGwjmJiMe.VfJ6iNdolBfkdSX4yrfoT5sH/qMrDza','Aixa Ramírez Toledo',0),
('javquiga','$2y$10$WoF94CWzEm.bYQ.I/rEG1.TzXnw59rKc53f1F7C3V33bc9lefAy36','Javier L. Quiñones Galán',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
